--Authors--
Jared Teller - jared.e.teller@wmich.edu
Joe Manto - joe.m.manto@wmich.edu

--Client--
J.K.K. Consulting.

--Licence--
This project is Licensed under the GNU General Public License version 3.
See LICENSE.txt in the root directory for more details.

--Acknowledgements--
Please refer to the References.txt file in the docs directory for proper acknowledgements.